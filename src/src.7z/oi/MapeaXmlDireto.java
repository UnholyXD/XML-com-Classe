//AQUI É O PQPCARAI

package oi;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;


public class MapeaXmlDireto {

	public static void main(String[] args) throws Exception {
		JAXBContext contexto = JAXBContext.newInstance(Racas.class);
		System.out.println("1 foi");
		
		Unmarshaller unmarshaller = contexto.createUnmarshaller();
		System.out.println("2 foi");
		Racas racas = (Racas) unmarshaller.unmarshal(new File("src/racas.xml"));
		

		System.out.println("3 foi");
		System.out.println(racas);

	}

}