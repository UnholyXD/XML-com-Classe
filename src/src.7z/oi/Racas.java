
package oi;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Racas {

    @SerializedName("racas")
    @Expose
    private Racas_ racas;

    public Racas_ getRacas() {
        return racas;
    }

    public void setRacas(Racas_ racas) {
        this.racas = racas;
    }

    public Racas withRacas(Racas_ racas) {
        this.racas = racas;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("racas", racas).toString();
    }

}
