
package oi;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Raca {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("nome")
    @Expose
    private String nome;
    @SerializedName("atributos")
    @Expose
    private String atributos;
    @SerializedName("contra")
    @Expose
    private String contra;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Raca withId(String id) {
        this.id = id;
        return this;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Raca withNome(String nome) {
        this.nome = nome;
        return this;
    }

    public String getAtributos() {
        return atributos;
    }

    public void setAtributos(String atributos) {
        this.atributos = atributos;
    }

    public Raca withAtributos(String atributos) {
        this.atributos = atributos;
        return this;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }

    public Raca withContra(String contra) {
        this.contra = contra;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).append("nome", nome).append("atributos", atributos).append("contra", contra).toString();
    }

}
