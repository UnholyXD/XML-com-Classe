
package oi;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Racas_ {

    @SerializedName("raca")
    @Expose
    private List<Raca> raca = null;

    public List<Raca> getRaca() {
        return raca;
    }

    public void setRaca(List<Raca> raca) {
        this.raca = raca;
    }

    public Racas_ withRaca(List<Raca> raca) {
        this.raca = raca;
        return this;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("raca", raca).toString();
    }

}
